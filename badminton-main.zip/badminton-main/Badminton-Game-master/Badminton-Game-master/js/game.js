var canvas = document.getElementById('game');
//////////////////////////////////////////////////////////////
//All Postions Variable 
var ctx = canvas.getContext('2d');
var height = canvas.height / 1.2;
var flag = 0;
var Distance;
var x_pos = 180;
var y_pos = height - 1;
var gr = 0;
//var angle = (45 * (Math.PI) / 180);
var requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame ;
var cancelAnimationFrame = window.cancelAnimationFrame || window.mozCancelAnimationFrame;
var animationstart;
var left_player_x = 120;
var right_player_x = 1000;
var left_player_y = 200;
var right_player_y = 600;
var leftscore = 0;
var rightscore = 0;
//Jump
var r_grr = 0, l_grr = 0;
var jump_speed = 5;
var h_vel = 5.5;
var v_vel = 5.5;
var racket_left = 0;
var racket_left_x = 0;
var racket_left_y = -60;
var racket_right = 0;
var racket_right_x = 0;
var racket_right_y = -60;
///////////////////////////////////////////////////////////////
//All Boolean Variable 
var a_pressed = false;
var s_pressed = false;
var d_pressed = false;
var left_pressed = false;
var right_pressed = false;
var down_pressed = false;
var jump_left = false;
var jump_right = false;
var rotate_flag_right = false;
var rotate_flag_left = false;
///////////////////////////////////////////////////////////////
//All Audio Variable 
var whistle = new Audio('assets/whistle.mp3');
var hit = new Audio('assets/hit.mp3');
var finish = new Audio('assets/finish.mp3');
///////////////////////////////////////////////////////////////
//All Images Variable 
var img = new Image();
var imgleftplayer = leftplayer = new Image();
var imgrightplayer = rightplayer = new Image();
var egg = new Image(); 
var no_egg =new Image();
var img = new Image();
var leftplayer_racket = new Image();
var rightplayer_racket = new Image();
///////////////////////////////////////////////////////////////
img.src = 'Images/shuttle.svg';
leftplayer_racket.src = 'Images/racket-left.png';
rightplayer_racket.src = 'Images/racket-right.png';
img.src = 'Images/shuttle.svg';
imgleftplayer.src = 'Images/left.png';
imgrightplayer.src = 'Images/right.png';
egg.src = 'Images/egg.png';
no_egg.src='Images/blank.png';
////////////////////////////console.log(Arena);////////////////
//Codn Variable for Arena
var Arena = sessionStorage.getItem("Arena");
if (Arena == "Arena1") {
    canvas.style.backgroundImage = "url('Images/back1.png')"
}
else if (Arena == "Arena2") {
    canvas.style.backgroundImage = "url('Images/back2.png')"
}
else if (Arena == "Arena3") {
    canvas.style.backgroundImage = "url('Images/back3.png')"
}
////////////////////////////console.log(Bird);////////////////
//Codn Variable for Birds
var Bird = sessionStorage.getItem("Bird");
if (Bird == "Bird_blue") {
    imgleftplayer.src = 'Images/left.png';
}
else if (Bird == "Bird_she") {
    imgleftplayer.src = 'Images/left_she.png';
}
else if (Bird == "Bird_red") {
    imgleftplayer.src = 'Images/left_red.png';
}
else if (Bird == "Bird_black") {
    imgleftplayer.src = 'Images/left_black.png';
}
else if (Bird == "Bird_yellow") {
    imgleftplayer.src = 'Images/left_yellow.png';
}
else if (Bird == "Bird_white") {
    imgleftplayer.src = 'Images/left_white.png';
}
////////////////////////////console.log(Pig);////////////////
//Codn Variable for Pig
var Pig =sessionStorage.getItem("Pig");
if (Pig=="pig_green")
{
    imgrightplayer.src='Images/right.png';
}
else if (Pig=="pig_she")
{
    imgrightplayer.src='Images/right_she.png';
}
else if (Pig=="pig_hitler")
{
    imgrightplayer.src='Images/right_old.png';
}
else if (Pig=="pig_zombie")
{
    imgrightplayer.src='Images/right_zombie.png';
}
///////////////////////////////////////////////////////////////
//Initial Animation start Request
animationstart = requestAnimationFrame(draw);
///////////////////////////////////////////////////////////////
function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    //Shuttle Dir'n
    if (flag == 0 || flag == 2 || flag == 4) ctx.drawImage(img, x_pos, y_pos, 30, 30);
    else rotate_shuttle();

    LeftPlayer();
    RightPlayer();
    net_collision();
    Jump_left();
    Jump_right();
    CheckGround();
    ControlCheck();
    EggLeft();
    EggRight();
    win_logic()

}
///////////////////////////////////////////////////////////////
//Used to Reset Position
function ResetPosition() {
    setTimeout(function () {
        location.reload();
    }, 2000)

}
///////////////////////////////////////////////////////////////
//Rotate Shuttle Logic
function rotate_shuttle() {
    ctx.save();
    ctx.translate(40, 40);
    ctx.rotate(180 * (Math.PI / 180));
    ctx.drawImage(img, -x_pos, -y_pos, 30, 30);
    ctx.restore();
}
///////////////////////////////////////////////////////////////
//Rotate Racket to left Logic
function rotate_racket_left() {
    ctx.save();
    ctx.translate(left_player_x - 60, left_player_y);
    if (racket_left_x < 50) {
        ctx.rotate(racket_left * Math.PI / 180);
        ctx.drawImage(leftplayer_racket, racket_left_x, racket_left_y, 120, 120);
    }
    else rotate_flag_left = false;
    racket_left += 1;
    racket_left_x += 2;
    racket_left_y -= 2;
    ctx.restore();
}

///////////////////////////////////////////////////////////////
//Rotate Racket to Right Logic
function rotate_racket_right() {
    ctx.save();
    ctx.translate(right_player_x - 60, right_player_y);
    if (racket_right_x < 50) {
        ctx.rotate(racket_right * Math.PI / 180);
        ctx.drawImage(rightplayer_racket, racket_right_x + 50, racket_right_y, 120, 120);
    }
    else rotate_flag_right = false;
    racket_right += 1;
    racket_right_x += 2;
    racket_right_y -= 2;
    ctx.restore();
}
///////////////////////////////////////////////////////////////
//Check shuttle and ground logic
function CheckGround() {
    if (x_pos <= 100 || x_pos >= 1300) {
        cancelAnimationFrame(animationstart);
        msgShownFN("Outside");
        ResetPosition();
    }
    else if (y_pos >= canvas.height - 100) {

        cancelAnimationFrame(animationstart);
        ResetPosition();
        if (x_pos <= canvas.width / 2) {
            console.log("Left");
            msgShownFN("Point");
            if (localStorage.getItem("RS")!=null)
            {
                rightscore=localStorage.getItem("RS");
            }
            rightscore++;
            console.log("Right Score : "+rightscore);
            localStorage.setItem("RS", rightscore);
        }

         if (x_pos >= canvas.width / 2) {
            console.log("Right");
            msgShownFN("Point");
            if (localStorage.getItem("LS")!=null)
            {
                leftscore=localStorage.getItem("LS");
            }
            leftscore++;
            console.log("Left Score : "+leftscore);
            localStorage.setItem("LS", leftscore);
        }
    }
    else {
        animationstart = requestAnimationFrame(draw);
    }
}
///////////////////////////////////////////////////////////////
//Used to show prompt Message
function msgShownFN(str) {
    ctx.save();
    ctx.translate(-canvas.width / 2, -100);
    ctx.beginPath();
    ctx.rect(canvas.width / 2, canvas.height / 2 + 60, canvas.width, 120);
    ctx.fillStyle = '#191970';
    ctx.fill();
    ctx.restore();
    ctx.font = "70px Bree Serif";
    ctx.fillStyle = "white";
    ctx.textAlign = "center";
    ctx.fillText(str, canvas.width / 2, canvas.height / 2 + 50);
    whistle.play();
    setTimeout(function () {
        ctx.fill("", -canvas.width / 2, -canvas.height / 2);
        msgShown = false;
    }, 2000)
}
/////////////////////////////////////////////////////////////
function FinishFN(str) {
    if(str=="Pig")
    {
        sessionStorage.setItem("Win", "Pig");
        window.location = "end.html";
    }
    else 
    {
        sessionStorage.setItem("Win", "Bird");
        window.location = "end.html";
    }
}

///////////////////////////////////////////////////////////////
//Fn for Left Player
function LeftPlayer() {
    ctx.beginPath();
    if (rotate_flag_left) rotate_racket_left();
    else
        ctx.drawImage(leftplayer_racket, left_player_x - 20, left_player_y - 60, 120, 120);

    ctx.drawImage(leftplayer, left_player_x, left_player_y, 120, 120);
    ctx.drawImage(imgleftplayer, left_player_x, left_player_y, 120, 120);
    ctx.closePath();
    if (d_pressed && left_player_x < 580 && s_pressed) {
        left_player_x += h_vel;
    }
    else if (a_pressed && left_player_x > 0 && s_pressed) {
        left_player_x -= h_vel;
    }
    else if (a_pressed && left_player_x > 0) {
        left_player_x -= h_vel;
    }
    else if (d_pressed && left_player_x < 580) {
        left_player_x += h_vel;
    }
    else {
        left_player_x += 0;
    }
}
///////////////////////////////////////////////////////////////
//Fn for Right Player
function RightPlayer() {
    ctx.beginPath();
    if (rotate_flag_right) rotate_racket_right();
    else
        ctx.drawImage(rightplayer_racket, right_player_x - 30, right_player_y - 60, 120, 120);
    ctx.drawImage(rightplayer, right_player_x, right_player_y, 120, 120);
    ctx.drawImage(imgrightplayer, right_player_x, right_player_y, 120, 120);
    ctx.closePath();
    if (left_pressed && right_player_x > 680 && down_pressed) {
        right_player_x -= h_vel;
    }
    else if (right_pressed && right_player_x < 1200 && down_pressed) {
        right_player_x += h_vel;
    }
    else if (left_pressed && right_player_x > 680) {
        right_player_x -= h_vel;
    }
    else if (right_pressed && right_player_x < 1200) {
        right_player_x += h_vel;
    }
    else {
        right_player_x += 0;
    }
}
///////////////////////////////////////////////////////////////
//Racket Collision With Shuttle and Change it's direction
function racket_left_dir_change() {
    Distance = Math.sqrt((x_pos - left_player_x) * (x_pos - left_player_x) + (y_pos - left_player_y) * (y_pos - left_player_y));
    if (Distance < 100) {
        flag = 1;
        hit.play();
    }
}
function racket_right_dir_change() {
    Distance = Math.sqrt((x_pos - right_player_x) * (x_pos - right_player_x) + (y_pos - right_player_y) * (y_pos - right_player_y));
    if (Distance < 100) {
        flag = 3;
        hit.play();
    }
}
///////////////////////////////////////////////////////////////
//Left Player Jump Logic
function Jump_left() {
    if (jump_left == true && left_player_y > 400) {
        left_player_y -= jump_speed;
    }
    else if (left_player_y < 600) {
        left_player_y += jump_speed;
    }
    else {
        jump_left = false;
    }
    if (rotate_flag_left) racket_left_dir_change();
}
///////////////////////////////////////////////////////////////
//Right Player Jump Logic
function Jump_right() {
    if (jump_right == true && right_player_y > 400) {
        right_player_y -= jump_speed;
    }
    else if (right_player_y < 600) {
        right_player_y += jump_speed;
    }
    else {
        jump_right = false;
    }
    if (rotate_flag_right) racket_right_dir_change();
}
///////////////////////////////////////////////////////////////
//Control check For players
function ControlCheck() {
    if (jump_left) left_player_y -= gr;
    if (jump_right) right_player_y -= r_grr;
    if (flag == 1) {
        if (x_pos < canvas.width - 30) {
            x_pos += h_vel;
            y_pos -= v_vel;
        }
    }
    else if (flag == 3) {
        if (x_pos < canvas.width - 30) {
            x_pos -= h_vel;
            y_pos -= v_vel;
        }
    }
    else if (flag == 4) {
        if (x_pos < canvas.width - 30) {
            x_pos += h_vel;
            y_pos += v_vel;
        }
    }
    else if (flag == 2) {
        if (x_pos < canvas.width - 30) {
            x_pos -= h_vel;
            y_pos += v_vel;
        }
    }
    else if (flag == 0) {
        if (x_pos < canvas.width - 30) {
            x_pos += h_vel;
            y_pos -= v_vel;
        }
    }
}
///////////////////////////////////////////////////////////////
//Logic for egg Change
function EggLeft() {
    if (flag == 1) {
        Distance = Math.sqrt((x_pos - left_player_x) * (x_pos - left_player_x) + (y_pos - left_player_y) * (y_pos - left_player_y));
        if (Distance < 100) {
            ctx.drawImage(egg, left_player_x, left_player_y, 120, 120);
            ctx.drawImage(egg, left_player_x, left_player_y, 120, 120);
        }
        else {
            ctx.drawImage(no_egg, left_player_x, left_player_y, 120, 120);
            ctx.drawImage(no_egg, left_player_x, left_player_y, 120, 120);
        }
    }
}
///////////////////////////////////////////////////////////////
//Logic for Egg Change
function EggRight() {
    if (flag == 3) {
        Distance = Math.sqrt((x_pos - right_player_x) * (x_pos - right_player_x) + (y_pos - right_player_y) * (y_pos - right_player_y));
        if (Distance < 100) {
            ctx.drawImage(egg, right_player_x, right_player_y, 120, 120);
            ctx.drawImage(egg, right_player_x, right_player_y, 120, 120);
        }
        else {
            ctx.drawImage(no_egg, right_player_x, right_player_y, 120, 120);
            ctx.drawImage(no_egg, right_player_x, right_player_y, 120, 120);
        }
    }
}
///////////////////////////////////////////////////////////////
//Win Logic
function win_logic() {
    if (localStorage.getItem("RS") == 1) {
        finish.play();
        FinishFN("Pig");
    }
    if (localStorage.getItem("LS") == 1) {
        finish.play();
        FinishFN("Bird");
    }
}
///////////////////////////////////////////////////////////////
//Used to Check Net Collision
function net_collision() {
    if ((x_pos >= (canvas.width / 2) - 30 && x_pos <= (canvas.width / 2) + 30) && y_pos >= canvas.height - 200) {
        if (flag == 1) flag = 2;
        else if (flag == 3) flag = 4;
        else if (flag == 2) flag = 1;
        else if (flag == 4) flag = 3;
    }
}

///////////////////////////////////////////////////////////////
//Event Listner for User Interaction
document.addEventListener("keydown", keyDownHandler, false);
document.addEventListener("keyup", keyUpHandler, false);
function keyDownHandler(e) {
    if (e.key == 'a') {
        a_pressed = true;
    }
    else if (e.key == 'd') {
        d_pressed = true;
    }
    if (e.key == 'w') {
        jump_left = true;
    }
    if (e.key == 's') {
        s_pressed = true;
        rotate_flag_left = true;
    }
    if (e.keyCode == 39) {
        right_pressed = true;
    }
    else if (e.keyCode == 37) {
        left_pressed = true;
    }
    if (e.keyCode == 38) {
        jump_right = true;
    }
    if (e.keyCode == 40) {
        down_pressed = true;
        rotate_flag_right = true;
    }
}
function keyUpHandler(e) {
    if (e.key == 'a') {
        a_pressed = false;
    }
    else if (e.key == 'd') {
        d_pressed = false;
    }
    if (e.key == 's') {
        s_pressed = false;
        rotate_flag_left = false;
    }
    if (e.keyCode == 39) {
        right_pressed = false;
    }
    else if (e.keyCode == 37) {
        left_pressed = false;
    }
    if (e.keyCode == 40) {
        down_pressed = false;
        rotate_flag_right = false;
    }
}
